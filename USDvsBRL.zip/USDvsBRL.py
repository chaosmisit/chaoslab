#USD versus BRL forecasting model (LSTM)

#Setup

import pandas as pd
import numpy as np
import tensorflow as tf
from tensorflow.keras import backend as K 
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
from tensorflow.keras.layers import LSTM
from tensorflow.keras.callbacks import EarlyStopping
from sklearn.preprocessing import MinMaxScaler
from tensorflow.keras.regularizers import l1
# Make numpy values easier to read.
np.set_printoptions(precision=3, suppress=True)


#   Data collection

#Load Data
df = pd.read_csv('Cotacoes.txt')


#   Data cleaning


#Converting string to datetime
df["Date"] = pd.to_datetime(df["Date"],format = '%d.%m.%Y')

#Setting date column to index of dataframe while dropping the current index
ind_date = df.set_index(["Date"], drop=True)

#Sorting the dataset in ascending order of date
data_frame = ind_date.sort_index(axis=0 ,ascending=True)
data_frame = data_frame.iloc[::-1]
#data_frame.head()


# Feature extraction


#Setting the split date
split_date = pd.Timestamp('2021-02-10')

#Creating training dataframe
train = data_frame.loc[split_date:]

#Creating test dataframe
test = data_frame.loc[:split_date]

#Normalizing data (sklearn)
sc = MinMaxScaler(feature_range=(0, 1))
train_sc = sc.fit_transform(train)
test_sc = sc.transform(test)


#Spliting the data
y_train = train_sc[:-1]
x_train = train_sc[1:]
y_test = test_sc[:-1]
x_test = test_sc[1:]

#Reshape into 3D
rextrain = x_train.reshape(x_train.shape[0], 1, x_train.shape[1])
rextest = x_test.reshape(x_test.shape[0], 1, x_test.shape[1])
reytrain = y_train.reshape(y_train.shape[0], 1, y_train.shape[1])


#      Model Validation

#Adding layers
K.clear_session()
model = Sequential()
model.add(LSTM(18, input_shape=(1, 1), kernel_regularizer=l1(0.01), recurrent_regularizer=l1(0.15), bias_regularizer=l1(0.08)))
model.add(Dense(1,activation='relu'))
model.summary()

#Compiling and fitting the model
model.compile(loss=tf.keras.metrics.mean_squared_error, metrics=[tf.keras.metrics.RootMeanSquaredError(name='rmse')], optimizer='adam')
early_stop = EarlyStopping(monitor='loss', patience=2, verbose=1)
model.fit(rextrain, y_train, epochs=10, batch_size=1, verbose=1, callbacks=[early_stop], shuffle=False)

#Accuracy check
_, accuracy = model.evaluate(rextrain, y_train)
print('Accuracy: %.2f' % (accuracy*100))

#Predicting
predictions = model.predict(rextest)


#   Visualization


#Reversing normalization
finalpred = sc.inverse_transform(predictions)

#Processing the data
dfpred = pd.DataFrame(finalpred)

#Getting data indexed by date

##Slicing test to match dfpred length
newtest = test[:-1]

#Setting date column to index of dataframe while dropping the current index
ind_dfpred = dfpred.set_index(newtest.index)
#Sorting the dataset in ascending order of date
pred_frame = ind_dfpred.sort_index(axis=0 ,ascending=True)
pred_frame = pred_frame.iloc[::-1]
#Relabeling
pred_frame.columns = ['BLR']

#Plotting prediction versus test dataframe (with train dataframe as history)
ax = train.plot(kind='line',figsize=(12,8))
test.plot(ax=ax, kind='line',figsize=(12,8),color='r')
pred_frame.plot(ax=ax, kind='line',figsize=(12,8),color='g')
ax.legend(['train', 'test', 'prediction'])
