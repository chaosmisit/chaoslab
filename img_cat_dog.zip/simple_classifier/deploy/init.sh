#!/bin/bash
export FLASK_APP=deploy.py
flask run
