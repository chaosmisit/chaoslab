import base64
import numpy as np
import io
from PIL import Image
import keras
from keras import backend as K
from keras.models import Sequential
from keras.models import load_model
from keras.preprocessing.image import ImageDataGenerator
from keras.preprocessing.image import img_to_array
from flask import request
from flask import jsonify
from flask import Flask

app = Flask(__name__)

def get_model():
	global model
	model = load_model('model.h5')
	print(" * Done!")
	
def preprocess_image(image, target_size):
	if image.mode !="RGB":
		image = image.convert("RGB")
	image = image.resize(target_size)
	image = img_to_array(image)
	image = np.expand_dims(image, axis=0)
	return image
	
print(" * Loading...")
get_model()

@app.route("/predict", methods=["POST"])
def predict():
	message = request.get_json(force=True)
	encoded = message['image']
	decoded = base64.b64decode(encoded)
	image = Image.open(io.BytesIO(decoded))
	processed_image = preprocess_image(image, target_size=(180, 180))
	prediction = model.predict(processed_image)
	prediction = float(prediction)
	cat_score = 100 * (1 - prediction)
	dog_score = 100 * prediction	
	
	
	response = {
		'prediction': {
			'dog': dog_score,
			'cat': cat_score
		}
	}
	return jsonify(response)
